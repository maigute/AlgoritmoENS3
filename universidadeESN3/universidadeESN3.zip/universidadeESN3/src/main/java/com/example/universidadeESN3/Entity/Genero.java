package com.example.universidadeESN3.Entity;

public enum Genero {
    FEMININO,
    MASCULINO,
    OUTROS
}
