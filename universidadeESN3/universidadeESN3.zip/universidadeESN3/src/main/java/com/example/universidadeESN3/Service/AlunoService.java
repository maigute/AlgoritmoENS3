package com.example.universidadeESN3.Service;

import com.example.universidadeESN3.Entity.Aluno;

import java.util.List;

public class AlunoService implements IAlunoService{
    @Override
    public Aluno buscarPorId(Long id) {
        return null;
    }

    @Override
    public List<Aluno> buscarTodos() {
        return null;
    }

    @Override
    public Aluno salvar(Aluno aluno) {
        return null;
    }

    @Override
    public void atualizar(Aluno aluno) {

    }

    @Override
    public void excluir(Long id) {

    }

    public Object BuscarTodos() {
    }
}
