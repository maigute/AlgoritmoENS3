package com.example.universidadeESN3.Controler;

public class ProfessorController {
}
